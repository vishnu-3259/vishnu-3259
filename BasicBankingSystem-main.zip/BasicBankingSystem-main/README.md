
# Developed by - RITIK DHABEKAR


# The Sparks Foundation Internship Project :
## Task- Basic Banking System
> Basic Banking System- https://ritikdhabekar.github.io/BasicBankingSystem/

A Dynamic Website to transfer money among 10 dummy users and to keep track of transaction history also, created by using HTML, CSS, Bootstrap & Javascript
